App({
  globalData: {
    // 云开发环境（2026-10-29 建成，免费微信体验版）。
    cloudEnv: 'yangshu598-001-d4glzg27uf2cac273',
    cloudReady: false,
    cloudDbg: '未初始化' // 临时诊断，提审前删除
  },
  onLaunch: function () {
    if (typeof wx.cloud === 'undefined') {
      this.globalData.cloudDbg = 'wx.cloud 不存在';
      return;
    }
    try {
      wx.cloud.init({ env: this.globalData.cloudEnv, traceUser: true });
      this.globalData.cloudReady = true;
      this.globalData.cloudDbg = '初始化成功';
    } catch (e) {
      this.globalData.cloudReady = false;
      this.globalData.cloudDbg = '初始化失败：' + (e && (e.errMsg || e.message) || e);
    }
  }
})
