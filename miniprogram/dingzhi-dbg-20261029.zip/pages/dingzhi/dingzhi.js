// 计价与表单逻辑与网站 order.js 同款（价格、包邮、满赠规则一致）。
// 提交与验证码走云函数 order-relay（云函数再 POST 到现有 Apps Script /exec）。
// 云服务不可用时退回本地文案 + 复制 fallback（与网站失败路径一致）。
var ITEMS = [
  { name: '原味棉袜', price: 48 },
  { name: '原味丝袜', price: 58 },
  { name: '原味内裤', price: 68 },
  { name: '原味老北京布鞋', price: 88 },
  { name: '原味正装衬衫', price: 188.88 },
  { name: '原味正装西裤', price: 188.88 },
  { name: '原味正装皮鞋', price: 588.88 },
  { name: '牛奶', price: 199.99 }
];
var SHIP_FREE_AT = 58, SHIP_FEE = 18, GIFT_AT = 200;

function money(n) { return n.toFixed(2); }

function cloudOK() {
  var app = getApp();
  return typeof wx.cloud !== 'undefined' && wx.cloud.callFunction &&
    app && app.globalData && app.globalData.cloudReady;
}

Page({
  data: {
    items: ITEMS.map(function (i) { return { name: i.name, price: i.price, qty: 0 }; }),
    goods: '0.00', ship: '0.00', total: '0.00', gift: false,
    contact: '', email: '', repeatRef: '', recipient: '', phone: '', address: '', note: '', captcha: '',
    captchaToken: '', captchaImg: '', captchaFail: false,
    cloudDbg: '', // 临时诊断，提审前删除
    orderText: '', showOrder: false, submitting: false
  },
  // 临时诊断：拼出云状态基线（对象有无 / 就绪 / 初始化结果）。
  dbgBase: function () {
    var app = getApp();
    var g = (app && app.globalData) || {};
    return '云对象：' + (typeof wx.cloud === 'undefined' ? '无' : '有') +
      ' / 就绪：' + (g.cloudReady ? '是' : '否') +
      ' / 初始化：' + (g.cloudDbg || '未知');
  },
  onLoad: function () { this.setData({ cloudDbg: this.dbgBase() }); this.loadCaptcha(); },
  loadCaptcha: function () {
    var self = this;
    if (!cloudOK()) { this.setData({ captchaFail: true, captchaImg: '', cloudDbg: this.dbgBase() + ' / 门拦截：未就绪' }); return; }
    wx.cloud.callFunction({
      name: 'order-relay', data: { action: 'challenge' },
      success: function (res) {
        var r = res.result || {};
        if (r.ok && r.token && r.imgUrl) {
          self.setData({ captchaToken: r.token, captchaImg: r.imgUrl, captchaFail: false, cloudDbg: self.dbgBase() + ' / 验证码已取到' });
        } else {
          self.setData({ captchaFail: true, captchaImg: '', cloudDbg: self.dbgBase() + ' / 函数回：' + JSON.stringify(r).slice(0, 100) });
        }
      },
      fail: function (err) { self.setData({ captchaFail: true, captchaImg: '', cloudDbg: self.dbgBase() + ' / 调用失败：' + (err && err.errMsg || '未知') }); }
    });
  },
  calc: function () {
    var goods = 0;
    this.data.items.forEach(function (i) { goods += i.price * i.qty; });
    var ship = goods === 0 ? 0 : (goods >= SHIP_FREE_AT ? 0 : SHIP_FEE);
    this.setData({
      goods: money(goods), ship: money(ship), total: money(goods + ship),
      gift: goods >= GIFT_AT
    });
  },
  step: function (e) {
    var idx = e.currentTarget.dataset.index;
    var delta = e.currentTarget.dataset.delta;
    var items = this.data.items;
    var q = items[idx].qty + delta;
    if (q < 0) q = 0;
    if (q > 99) q = 99;
    items[idx].qty = q;
    this.setData({ items: items });
    this.calc();
  },
  bindInput: function (e) {
    var f = e.currentTarget.dataset.field;
    var o = {};
    o[f] = e.detail.value;
    this.setData(o);
  },
  makeRef: function () {
    var d = new Date();
    var y = d.getFullYear();
    var m = ('0' + (d.getMonth() + 1)).slice(-2);
    var day = ('0' + d.getDate()).slice(-2);
    var seq = (wx.getStorageSync('orderSeq') || 0) + 1;
    wx.setStorageSync('orderSeq', seq);
    return '' + y + m + day + '-' + ('00' + seq).slice(-3);
  },
  buildOrderText: function (ref) {
    var lines = ['订单参考号：' + ref];
    this.data.items.forEach(function (i) {
      if (i.qty > 0) lines.push(i.name + ' x' + i.qty + ' = ¥' + money(i.price * i.qty));
    });
    lines.push('商品合计：¥' + this.data.goods);
    lines.push('运费：¥' + this.data.ship + '（满¥58包邮）');
    if (this.data.gift) lines.push('满¥200送牛奶（付款后微信确认）');
    lines.push('合计：¥' + this.data.total);
    lines.push('联系方式：' + this.data.contact);
    lines.push('邮箱：' + this.data.email);
    if (this.data.repeatRef) lines.push('上次订单参考号：' + this.data.repeatRef);
    lines.push('收件人：' + this.data.recipient);
    lines.push('电话：' + this.data.phone);
    lines.push('地址：' + this.data.address);
    if (this.data.note) lines.push('备注：' + this.data.note);
    lines.push('说明：本单为咨询/预约登记，非在线支付；提交后按邮件指引扫码付款并加微信确认。');
    return lines.join('\n');
  },
  validate: function () {
    var any = this.data.items.some(function (i) { return i.qty > 0; });
    if (!any) return '请先选一件单品';
    if (!this.data.contact) return '请填联系方式';
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(this.data.email)) return '请填正确格式的邮箱';
    if (!this.data.recipient) return '请填收件人';
    if (!/^\d{11}$/.test(this.data.phone)) return '电话请填 11 位数字';
    if (!this.data.address) return '请填地址';
    return '';
  },
  submit: function () {
    var self = this;
    var err = this.validate();
    if (err) { wx.showToast({ title: err, icon: 'none' }); return; }
    var ref = this.makeRef();
    var text = this.buildOrderText(ref);
    this.setData({ orderText: text, showOrder: true });
    // 云服务不可用：本地文案 + 复制 fallback，不要求验证码。
    if (!cloudOK()) {
      wx.showToast({ title: '请复制订单文案通过微信发送', icon: 'none' });
      return;
    }
    if (!this.data.captcha) { wx.showToast({ title: '请填验证码', icon: 'none' }); return; }
    var items = [];
    this.data.items.forEach(function (i) {
      if (i.qty > 0) items.push({ name: i.name, qty: i.qty, price: i.price });
    });
    this.setData({ submitting: true });
    wx.cloud.callFunction({
      name: 'order-relay',
      data: {
        action: 'submit', ref: ref, items: items,
        contact: this.data.contact, email: this.data.email, repeatRef: this.data.repeatRef,
        recipient: this.data.recipient, phone: this.data.phone, address: this.data.address,
        note: this.data.note, source: '',
        captchaToken: this.data.captchaToken, captchaAnswer: this.data.captcha
      },
      success: function (res) {
        var r = res.result || {};
        if (r.ok) {
          wx.showToast({ title: '提交成功，请查收邮件' });
        } else if (r.error === 'captcha') {
          wx.showToast({ title: '验证码不对，请重新填写。', icon: 'none' });
        } else if (r.error === 'captcha_expired') {
          wx.showToast({ title: '验证码已过期，请重新填写。', icon: 'none' });
        } else if (r.error === 'invalid order') {
          wx.showToast({ title: '订单信息不完整，请检查后重新提交。', icon: 'none' });
        } else {
          wx.showToast({ title: '提交失败，请复制订单文案', icon: 'none' });
        }
        // 后端对任何一次提交都作废 token（无论对错），所以每次提交后都换一张。
        self.loadCaptcha();
      },
      fail: function () {
        wx.showToast({ title: '提交失败，请复制订单文案', icon: 'none' });
      },
      complete: function () { self.setData({ submitting: false }); }
    });
  },
  copyOrder: function () {
    wx.setClipboardData({
      data: this.data.orderText,
      success: function () { wx.showToast({ title: '已复制' }); }
    });
  }
});
