Page({
  data: {
    posts: [
      { title: "你的叔｜秋冬袜子3个配色公式", cover: "cloud://yangshu598-001-d4glzg27uf2cac273/xhs-covers/img02-s.jpg" },
      { title: "你的叔｜想起他，都是这些细节", cover: "cloud://yangshu598-001-d4glzg27uf2cac273/xhs-covers/img06-s.jpg" },
      { title: "你的叔｜拖鞋旁的那双袜子", cover: "cloud://yangshu598-001-d4glzg27uf2cac273/xhs-covers/img10-s.jpg" },
      { title: "你的叔｜雨夜他先擦干净了鞋", cover: "cloud://yangshu598-001-d4glzg27uf2cac273/xhs-covers/img14-s.jpg" },
      { title: "你的叔｜行李箱最上面是袜子", cover: "cloud://yangshu598-001-d4glzg27uf2cac273/xhs-covers/img18-s.jpg" },
      { title: "你的叔｜加班那晚墨绿袜出卖了他", cover: "cloud://yangshu598-001-d4glzg27uf2cac273/xhs-covers/img01-s.jpg" },
      { title: "你的叔｜周日午后他教我系领带", cover: "cloud://yangshu598-001-d4glzg27uf2cac273/xhs-covers/img25-s.jpg" }
    ]
  },
  onPostTap: function () {
    wx.showToast({ title: "请在小红书 App 内搜索 杨树598 查看原帖", icon: "none", duration: 3000 });
  }
});
