Page({
  data: { url: "" },
  onLoad: function (options) {
    var title = options.title ? decodeURIComponent(options.title) : "文章";
    var url = options.url ? decodeURIComponent(options.url) : "";
    wx.setNavigationBarTitle({ title: title });
    this.setData({ url: url });
  }
});
