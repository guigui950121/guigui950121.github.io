Page({
  data: {
    channelId: "sphy1kaeKkxVI8M",
    posts: [
  {
    "title": "你的叔｜傍晚回家，酒红袜刚刚好",
    "date": "2026-10-28",
    "body": "傍晚回家，玄关脱下外套，客厅坐下来看会儿书，藏青西装配纯酒红袜，乐福鞋不系带，坐下来裤脚刚好露一截袜子，不抢戏刚刚好。"
  },
  {
    "title": "你的叔｜周末咖啡馆，墨绿袜刚刚好",
    "date": "2026-10-27",
    "body": "咖啡馆窗边看报，公园长椅上坐一会儿，深灰西装配纯墨绿袜，乐福鞋不系带，坐下来裤脚刚好露一截袜子，不抢戏刚刚好。"
  },
  {
    "title": "你的叔｜这身深灰，下午在书店坐下来刚刚好",
    "date": "2026-10-27",
    "body": "书店窗边，深灰西装配纯黑袜，乐福鞋不系带，坐下来看书，裤脚刚好露一截袜子，不抢戏刚刚好。"
  }
]
  },
  goChannel: function () {
    var that = this;
    if (wx.openChannelsUserProfile) {
      wx.openChannelsUserProfile({
        finderUserName: that.data.channelId,
        fail: function () {
          wx.showToast({ title: "打不开视频号，请在微信内搜索 杨树598", icon: "none", duration: 3000 });
        }
      });
    } else {
      wx.showToast({ title: "请在微信内搜索 杨树598", icon: "none", duration: 3000 });
    }
  },
  onPostTap: function () {
    this.goChannel();
  }
});
