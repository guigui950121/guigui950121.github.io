Page({
  data: {
    articles: [
  {
    "title": "周三晚上，他在理发店等剪发",
    "date": "2026-10-28 21:16",
    "url": "https://mp.weixin.qq.com/s/NSZfyJ9Hl1KS7jTP7hHg-Q"
  },
  {
    "title": "周日晚上，他在沙发上翻旧相册",
    "date": "2026-10-28 00:15",
    "url": "https://mp.weixin.qq.com/s/2JJ5S_LUdvtxQyyepebYag"
  },
  {
    "title": "周六下午，他在公园长椅上歇脚",
    "date": "2026-10-27 07:34",
    "url": "https://mp.weixin.qq.com/s/6vF9TdNWzQ0E6VqFJVrQyg"
  },
  {
    "title": "深夜，他在楼下便利店买关东煮",
    "date": "2026-10-26 08:05",
    "url": "https://mp.weixin.qq.com/s/SqA1hmYD5_E0tt1MsZYctQ"
  },
  {
    "title": "周日午后，他在书房翻旧杂志",
    "date": "2026-10-25 20:41",
    "url": "https://mp.weixin.qq.com/s/bgYzBenUZT6r12PoouPyJw"
  },
  {
    "title": "早高峰的地铁上，他把脚换了个姿势",
    "date": "2026-10-25 15:04",
    "url": "https://mp.weixin.qq.com/s/XenqXpIU4qYqo15Ae9yI0g"
  },
  {
    "title": "回程的高铁上，他把脚搁在了脚踏上",
    "date": "2026-10-25 12:34",
    "url": "https://mp.weixin.qq.com/s/HUJNrtDBu41cNexHMrT3RA"
  },
  {
    "title": "《出差第一晚，他换上了白袜子》",
    "date": "2026-10-24 09:37",
    "url": "https://mp.weixin.qq.com/s/hBw6zLKAYRepBvUSSAQs4g"
  },
  {
    "title": "周六晚上，他看球看到了加时",
    "date": "2026-10-24 01:08",
    "url": "https://mp.weixin.qq.com/s/7xki66x-CuAVp3rfITVzeA"
  },
  {
    "title": "《周末的咖啡馆，他把脚搭在了行李箱上》",
    "date": "2026-10-22 18:26",
    "url": "https://mp.weixin.qq.com/s/fr8y_whc4EdrcS8d_fAuqw"
  },
  {
    "title": "到家第一件事，他先把鞋踢了",
    "date": "2026-10-22 16:11",
    "url": "https://mp.weixin.qq.com/s/XfX3RLUkeJ4LQPdqPqzaZw"
  },
  {
    "title": "加班到深夜，他把鞋脱了",
    "date": "2026-10-14",
    "url": "https://mp.weixin.qq.com/s/Q7l-LOncfAP_f74Vc7OK1A"
  },
  {
    "title": "分享图片",
    "date": "2026-08-07",
    "url": "https://mp.weixin.qq.com/s/fb2eCVoiCle_1m7gQ55mRg"
  },
  {
    "title": "分享图片",
    "date": "2026-08-07",
    "url": "https://mp.weixin.qq.com/s/CkI6c4zXhqa7qtmIQBw5XA"
  },
  {
    "title": "分享图片",
    "date": "2026-08-07",
    "url": "https://mp.weixin.qq.com/s/wjUpmBawqBZ4A3vrCM1jFQ"
  },
  {
    "title": "分享图片",
    "date": "2026-08-07",
    "url": "https://mp.weixin.qq.com/s/k7lI_rzCyC2Gby7nkkpQ3Q"
  },
  {
    "title": "#你的叔#叔圈",
    "date": "2026-08-06",
    "url": "https://mp.weixin.qq.com/s/ptR52euD1RL1e2ImdZCsMQ"
  },
  {
    "title": "#中年大叔#你的叔",
    "date": "2026-08-05",
    "url": "https://mp.weixin.qq.com/s/DU8HTipdYOPkTo0dvwopEA"
  },
  {
    "title": "#中年大叔#你的叔#叔圈",
    "date": "2026-08-04",
    "url": "https://mp.weixin.qq.com/s/WR16IpEGM6fX9YY_4q8apg"
  },
  {
    "title": "#中年男人",
    "date": "2026-08-04",
    "url": "https://mp.weixin.qq.com/s/Fg91qag3kO3zJ_ZejlLncg"
  },
  {
    "title": "#你喜欢吗",
    "date": "2026-08-04",
    "url": "https://mp.weixin.qq.com/s/_R_vcaT1wyN1T3QriF5IeA"
  },
  {
    "title": "杨大爷的一天",
    "date": "2025-11-27",
    "url": "https://mp.weixin.qq.com/s/f4VNiCAI8TXPi_gt2UwWkQ"
  },
  {
    "title": "#深蓝袜子搭配#黑色皮鞋穿搭#中年大叔#叔圈",
    "date": "2025-11-11",
    "url": "https://mp.weixin.qq.com/s/JuolBvoWV1VZ8gzsBu07JQ"
  },
  {
    "title": "大杨叔私塾02（光脚篇）付费",
    "date": "2025-11-10",
    "url": "https://mp.weixin.qq.com/s/SmlGDYRu-zJx0LP3KqqpxA"
  },
  {
    "title": "大杨叔私塾01 付费",
    "date": "2025-11-09",
    "url": "https://mp.weixin.qq.com/s/BVnKu4OpXvuc224QGWM7Bw"
  },
  {
    "title": "大杨叔（）",
    "date": "2025-11-08",
    "url": "https://mp.weixin.qq.com/s/ty6VixqSGfCP8iLGFwEyMA"
  },
  {
    "title": "大杨叔（）",
    "date": "2025-11-07",
    "url": "https://mp.weixin.qq.com/s/VVpFHSoGbo1-ZCRsYmhCAw"
  },
  {
    "title": "大杨叔（）",
    "date": "2025-11-06",
    "url": "https://mp.weixin.qq.com/s/zh0W-3TlCgQG3IIvLOFmEA"
  },
  {
    "title": "大杨叔（）",
    "date": "2025-11-05",
    "url": "https://mp.weixin.qq.com/s/_U4F48DuCQqsIc8oTXDIAA"
  },
  {
    "title": "大杨叔（）",
    "date": "2025-11-04",
    "url": "https://mp.weixin.qq.com/s/EwJb9tma5KitNCcbewIvmA"
  },
  {
    "title": "大杨叔（）",
    "date": "2025-11-03",
    "url": "https://mp.weixin.qq.com/s/PWQSDDil71sCkoJ6n1G_7A"
  },
  {
    "title": "抖音：大杨叔（生活号）",
    "date": "2025-11-02",
    "url": "https://mp.weixin.qq.com/s/6L_IZjjeMnQ8Nj12QlyX1w"
  },
  {
    "title": "风月都好看，人间也浪漫",
    "date": "2025-11-01",
    "url": "https://mp.weixin.qq.com/s/FHYQuybuS_14Cakk3BFOHQ"
  },
  {
    "title": "心里装着美好，眼里的世界就美好",
    "date": "2025-10-31",
    "url": "https://mp.weixin.qq.com/s/QINzqojqzvYoBKb4EiPsBQ"
  },
  {
    "title": "👨‍🌾农民伯伯·棉纶丝袜的故事",
    "date": "2025-09-13",
    "url": "https://mp.weixin.qq.com/s/dqMdmlt0yc410DGMS3FkrQ"
  },
  {
    "title": "👨‍🌾农民伯伯·生活日常",
    "date": "2025-09-12",
    "url": "https://mp.weixin.qq.com/s/zcdOP4EKH1-MCnQhbM11Cw"
  },
  {
    "title": "👨‍🌾农民伯伯·田间一日",
    "date": "2025-09-11",
    "url": "https://mp.weixin.qq.com/s/qp1STEcN-ChHFE4bRN44yA"
  },
  {
    "title": "杨大爷250911",
    "date": "2025-09-11",
    "url": "https://mp.weixin.qq.com/s/w8E4g58r8flEqzC2cMk9qw"
  },
  {
    "title": "250910",
    "date": "2025-09-10",
    "url": "https://mp.weixin.qq.com/s/oXtOroTx8QXolrTy5vhzbQ"
  },
  {
    "title": "1224",
    "date": "2024-12-24",
    "url": "https://mp.weixin.qq.com/s/-zT-uEN75qQ4WoEZoXHiLA"
  },
  {
    "title": "杨蜀黍1215",
    "date": "2024-12-15",
    "url": "https://mp.weixin.qq.com/s/GtSF_HCkqgv5obV_U1Vjgw"
  },
  {
    "title": "杨蜀黍uncle",
    "date": "2024-12-13",
    "url": "https://mp.weixin.qq.com/s/-N9NkOm23_e2KXB7V_tmuw"
  },
  {
    "title": "杨蜀黍1212",
    "date": "2024-12-12",
    "url": "https://mp.weixin.qq.com/s/hmOST-jInRCxP_Az1Kj8BQ"
  },
  {
    "title": "杨蜀黍 1119",
    "date": "2024-11-19",
    "url": "https://mp.weixin.qq.com/s/Ftf_y3gZSS3Bdz32-YlAiA"
  },
  {
    "title": "杨蜀黍 1118",
    "date": "2024-11-18",
    "url": "https://mp.weixin.qq.com/s/vyDvohyTcZF_LKb1UBBmAg"
  },
  {
    "title": "上线",
    "date": "2024-11-17",
    "url": "https://mp.weixin.qq.com/s/Hrc_Zqg6w6NB3OUeXtHC5g"
  },
  {
    "title": "杨蜀黍 1115",
    "date": "2024-11-15",
    "url": "https://mp.weixin.qq.com/s/jJcqu8cCNpX_ekGSEEmxvg"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-11-03",
    "url": "https://mp.weixin.qq.com/s/S6Zb_sWujQK9SITNZXQfCg"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-11-02",
    "url": "https://mp.weixin.qq.com/s/8OQCHECXssMxowa-mUFkUA"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-11-01",
    "url": "https://mp.weixin.qq.com/s/ALunZ-NmmZwyKIZ1r3QWCw"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-10-30",
    "url": "https://mp.weixin.qq.com/s/Sn9qE89hVJUMWZ5iGIqphg"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-10-29",
    "url": "https://mp.weixin.qq.com/s/o1ZWleo1kTVtnP4D-oc87w"
  },
  {
    "title": "杨蜀黍 抵制任何形式的盗取！",
    "date": "2024-10-28",
    "url": "https://mp.weixin.qq.com/s/MtAtX2eHefXQ6DlDbJ35DA"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-10-27",
    "url": "https://mp.weixin.qq.com/s/TWGVAZ-a7hk8GSe7lcAvsg"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-10-25",
    "url": "https://mp.weixin.qq.com/s/wArrNUoKATkcdUn1Aq5UHQ"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-10-24",
    "url": "https://mp.weixin.qq.com/s/LBLnScQGUAipFSSB9ZhU6Q"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-10-23",
    "url": "https://mp.weixin.qq.com/s/gDiicI3wJ41sJ9dUlYh0Mw"
  },
  {
    "title": "杨蜀黍追求真实，拒绝过于完美",
    "date": "2024-10-22",
    "url": "https://mp.weixin.qq.com/s/N32rolYvVYSx7zR65rU8dQ"
  },
  {
    "title": "杨蜀黍追求真实，拒绝过于完美",
    "date": "2024-10-21",
    "url": "https://mp.weixin.qq.com/s/F0c3Tkl3BeFdYFq9knay7A"
  },
  {
    "title": "杨蜀黍追求真实，拒绝过于完美",
    "date": "2024-10-20",
    "url": "https://mp.weixin.qq.com/s/pCG9ZykXiR3uc0gDChMBCA"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-10-19",
    "url": "https://mp.weixin.qq.com/s/c_WgZp3MmXN66N3T0g_ASA"
  },
  {
    "title": "杨蜀黍",
    "date": "2024-10-18",
    "url": "https://mp.weixin.qq.com/s/56YsR4X23fl7hYJgVuo3tQ"
  }
]
  },
  onArticleTap: function (e) {
    var idx = e.currentTarget.dataset.idx;
    var a = this.data.articles[idx];
    wx.navigateTo({
      url: "/pages/webview/webview?url=" + encodeURIComponent(a.url) + "&title=" + encodeURIComponent(a.title)
    });
  }
});
