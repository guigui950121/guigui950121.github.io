App({
  globalData: {
    // 云开发中转地址：云函数建好后填入（云函数再 POST 到现有 Apps Script /exec）。
    // 为空时订同款页走本地文案 + 复制 fallback（与网站失败路径一致）。
    backendUrl: ''
  },
  onLaunch: function () {}
})
