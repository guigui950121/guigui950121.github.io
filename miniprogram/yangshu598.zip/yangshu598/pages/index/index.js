Page({
  goDingzhi: function () {
    wx.switchTab({ url: '/pages/dingzhi/dingzhi' })
  }
})
