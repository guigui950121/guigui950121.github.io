// 计价与表单逻辑与网站 order.js 同款（价格、包邮、满赠规则一致）。
var ITEMS = [
  { name: '原味棉袜', price: 48 },
  { name: '原味丝袜', price: 58 },
  { name: '原味内裤', price: 68 },
  { name: '原味老北京布鞋', price: 88 },
  { name: '原味正装衬衫', price: 188.88 },
  { name: '原味正装西裤', price: 188.88 },
  { name: '原味正装皮鞋', price: 588.88 },
  { name: '牛奶', price: 199.99 }
];
var SHIP_FREE_AT = 58, SHIP_FEE = 18, GIFT_AT = 200;

function money(n) { return n.toFixed(2); }

Page({
  data: {
    items: ITEMS.map(function (i) { return { name: i.name, price: i.price, qty: 0 }; }),
    goods: '0.00', ship: '0.00', total: '0.00', gift: false,
    contact: '', email: '', repeatRef: '', recipient: '', phone: '', address: '', note: '', captcha: '',
    orderText: '', showOrder: false, submitting: false
  },
  calc: function () {
    var goods = 0;
    this.data.items.forEach(function (i) { goods += i.price * i.qty; });
    var ship = goods === 0 ? 0 : (goods >= SHIP_FREE_AT ? 0 : SHIP_FEE);
    this.setData({
      goods: money(goods), ship: money(ship), total: money(goods + ship),
      gift: goods >= GIFT_AT
    });
  },
  step: function (e) {
    var idx = e.currentTarget.dataset.index;
    var delta = e.currentTarget.dataset.delta;
    var items = this.data.items;
    var q = items[idx].qty + delta;
    if (q < 0) q = 0;
    if (q > 99) q = 99;
    items[idx].qty = q;
    this.setData({ items: items });
    this.calc();
  },
  bindInput: function (e) {
    var f = e.currentTarget.dataset.field;
    var o = {};
    o[f] = e.detail.value;
    this.setData(o);
  },
  makeRef: function () {
    var d = new Date();
    var y = d.getFullYear();
    var m = ('0' + (d.getMonth() + 1)).slice(-2);
    var day = ('0' + d.getDate()).slice(-2);
    var seq = (wx.getStorageSync('orderSeq') || 0) + 1;
    wx.setStorageSync('orderSeq', seq);
    return '' + y + m + day + '-' + ('00' + seq).slice(-3);
  },
  buildOrderText: function (ref) {
    var lines = ['订单参考号：' + ref];
    this.data.items.forEach(function (i) {
      if (i.qty > 0) lines.push(i.name + ' x' + i.qty + ' = ¥' + money(i.price * i.qty));
    });
    lines.push('商品合计：¥' + this.data.goods);
    lines.push('运费：¥' + this.data.ship + '（满¥58包邮）');
    if (this.data.gift) lines.push('满¥200送牛奶（付款后微信确认）');
    lines.push('合计：¥' + this.data.total);
    lines.push('联系方式：' + this.data.contact);
    lines.push('邮箱：' + this.data.email);
    if (this.data.repeatRef) lines.push('上次订单参考号：' + this.data.repeatRef);
    lines.push('收件人：' + this.data.recipient);
    lines.push('电话：' + this.data.phone);
    lines.push('地址：' + this.data.address);
    if (this.data.note) lines.push('备注：' + this.data.note);
    lines.push('说明：本单为咨询/预约登记，非在线支付；提交后按邮件指引扫码付款并加微信确认。');
    return lines.join('\n');
  },
  validate: function () {
    var any = this.data.items.some(function (i) { return i.qty > 0; });
    if (!any) return '请先选一件单品';
    if (!this.data.contact) return '请填联系方式';
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(this.data.email)) return '请填正确格式的邮箱';
    if (!this.data.recipient) return '请填收件人';
    if (!/^\d{11}$/.test(this.data.phone)) return '电话请填 11 位数字';
    if (!this.data.address) return '请填地址';
    return '';
  },
  submit: function () {
    var self = this;
    var err = this.validate();
    if (err) { wx.showToast({ title: err, icon: 'none' }); return; }
    var ref = this.makeRef();
    var text = this.buildOrderText(ref);
    this.setData({ orderText: text, showOrder: true });
    var url = getApp().globalData.backendUrl;
    if (!url) {
      wx.showToast({ title: '请复制订单文案通过微信发送', icon: 'none' });
      return;
    }
    this.setData({ submitting: true });
    wx.request({
      url: url, method: 'POST',
      data: { ref: ref, orderText: text, contact: this.data.contact, email: this.data.email },
      success: function () { wx.showToast({ title: '提交成功' }); },
      fail: function () { wx.showToast({ title: '提交失败，请复制订单文案', icon: 'none' }); },
      complete: function () { self.setData({ submitting: false }); }
    });
  },
  copyOrder: function () {
    var self = this;
    wx.setClipboardData({
      data: this.data.orderText,
      success: function () { wx.showToast({ title: '已复制' }); }
    });
  }
});
